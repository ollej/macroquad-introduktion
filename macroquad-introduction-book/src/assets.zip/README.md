## Asset credits

### Sprites

**Space Ship Shooter Pixel Art Assets**  
Author: ansimuz  
License: CC0 Public Domain  
<https://opengameart.org/content/space-ship-shooter-pixel-art-assets>

### Theme music

**8-bit space shooter music**  
Author: HydroGene  
License: CC0 Public Domain  
<https://opengameart.org/content/8-bit-epic-space-shooter-music>

### Laser and explosion sounds

**Sci-fi sounds**  
Author: Kenney.nl  
License: CC0 Public Domain  
<https://opengameart.org/content/sci-fi-sounds>

### UI

**Sci-fi User Interface Elements**  
Author: Buch  
License: CC0 Public Domain  
sci-fi-ui.psd  
<https://opengameart.org/content/sci-fi-user-interface-elements>

### Font

**AtariGames**   
Author: Kieran  
License: Public Domain  
<https://nimblebeastscollective.itch.io/nb-pixel-font-bundle>

